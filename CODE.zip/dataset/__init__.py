class MusicDataset:
    pass